import cv2
import numpy as np
from ultralytics import YOLO
import cvzone

# Load YOLOv8 model
model = YOLO('yolov8n.pt')

# Target classes
TARGET_CLASSES = ["bottle", "cup", "book"]

# Webcam setup
camera = cv2.VideoCapture(0)
camera.set(3, 1280)  # Width
camera.set(4, 720)   # Height

# Screen center coordinates
screen_center_x = 640  # Center X of 1280 width
screen_center_y = 360  # Center Y of 720 height

# Coefficients for Z calculation (dummy values, tune as needed)
A, B, C = 0.012, -2.71, 182.62  # For distance-based Z estimation

while True:
    success, img = camera.read()
    if not success:
        break

    # Detect objects using YOLOv8
    results = model(img, show=False)

    for result in results[0].boxes:
        box = result.xyxy[0].numpy()  # Bounding box [x1, y1, x2, y2]
        conf = result.conf[0].item()  # Confidence
        cls_id = int(result.cls[0].item())  # Class ID
        class_name = model.names[cls_id]  # Class name

        # Filter only target classes
        if class_name in TARGET_CLASSES and conf > 0.5:
            x1, y1, x2, y2 = map(int, box)
            bx, by, bw, bh = x1, y1, x2 - x1, y2 - y1

            # Calculate center of the bounding box
            center_x = int((x1 + x2) / 2)
            center_y = int((y1 + y2) / 2)

            # Virtual distance (e.g., bounding box width or height)
            distance_virtual = bw

            # Calculate Z position (dummy logic, tune based on your setup)
            if distance_virtual > 150:
                Z_real = (-0.125 * distance_virtual) + 44.125
            elif 100 < distance_virtual <= 150:
                Z_real = (-0.217391 * distance_virtual) + 58.260869
            else:
                Z_real = (A * (distance_virtual ** 2)) + (B * distance_virtual) + C

            # Calculate X and Y positions relative to screen center
            X_virtual = -(center_x - screen_center_x)
            Y_virtual = -(center_y - screen_center_y)
            X_real = X_virtual * (6.3 / distance_virtual)  # Scaling factor
            Y_real = Y_virtual * (6.3 / distance_virtual)

            # Display calculated positions on screen
            cvzone.putTextRect(img, f'{int(X_real)}cm {int(Y_real)}cm {int(Z_real)}cm', (bx, by - 10))
            cv2.circle(img, (screen_center_x, screen_center_y), 5, (0, 0, 255), 2)  # Screen center
            cv2.rectangle(img, (x1, y1), (x2, y2), (255, 0, 0), 2)  # Bounding box

    # Display the frame
    cv2.imshow("YOLOv8 Object Tracking with 3D Positions", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to quit
        break

camera.release()
cv2.destroyAllWindows()
