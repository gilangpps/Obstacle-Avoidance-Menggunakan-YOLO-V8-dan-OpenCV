import cv2
import mediapipe as mp
import cvzone

# Setup MediaPipe Objectron
mp_objectron = mp.solutions.objectron
mp_drawing = mp.solutions.drawing_utils

# Initialize the Objectron detector for Cup, Bottle, and Shoe
models_to_detect = ['Cup', 'Bottle', 'Shoe']  # List of models to detect
max_objects = 5  # Detect up to 5 objects

# Webcam setup
camera = cv2.VideoCapture(0)
camera.set(3, 1280)  # Width
camera.set(4, 720)   # Height

if not camera.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Initialize the Objectron detector
objectron = mp_objectron.Objectron(
    static_image_mode=False,
    max_num_objects=max_objects,  # Detect up to 5 objects
    min_detection_confidence=0.5,
    model_name='Cup'  # Start by detecting Cup; can be replaced with 'Bottle' or 'Shoe'
)

# Screen center coordinates
screen_center_x = 640  # Center X of 1280 width
screen_center_y = 360  # Center Y of 720 height

# Coefficients for Z calculation (dummy values, tune as needed)
A, B, C = 0.012, -2.71, 182.62  # For distance-based Z estimation

while True:
    success, img = camera.read()
    if not success:
        print("Error: Failed to capture image.")
        break

    # Convert the image to RGB (MediaPipe uses RGB images)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Process the image with Objectron to detect objects
    results = objectron.process(img_rgb)

    # Check if any objects are detected
    if results.detected_objects:
        for detected_object in results.detected_objects:
            # Draw bounding box for each detected object
            mp_drawing.draw_landmarks(img, detected_object, mp_objectron.BOX_CONNECTIONS)

            # Get the bounding box and landmarks for position calculations
            box = detected_object.location_data.relative_bounding_box
            center_x = int((box.xmin + box.xmin + box.width) / 2 * img.shape[1])
            center_y = int((box.ymin + box.ymin + box.height) / 2 * img.shape[0])
            width = int(box.width * img.shape[1])
            height = int(box.height * img.shape[0])

            # Calculate virtual distance (e.g., using width)
            distance_virtual = width

            # Calculate Z position (dummy logic, tune based on your setup)
            if distance_virtual > 150:
                Z_real = (-0.125 * distance_virtual) + 44.125
            elif 100 < distance_virtual <= 150:
                Z_real = (-0.217391 * distance_virtual) + 58.260869
            else:
                Z_real = (A * (distance_virtual ** 2)) + (B * distance_virtual) + C

            # Calculate X and Y positions relative to screen center
            X_virtual = -(center_x - screen_center_x)
            Y_virtual = -(center_y - screen_center_y)
            X_real = X_virtual * (6.3 / distance_virtual)  # Scaling factor
            Y_real = Y_virtual * (6.3 / distance_virtual)

            # Display calculated positions on screen
            # As MediaPipe Objectron doesn't provide a label directly, we'll display the model's type based on its index
            # 0 -> Cup, 1 -> Bottle, 2 -> Shoe
            model_type = models_to_detect[detected_object.label] if detected_object.label < len(models_to_detect) else 'Unknown'

            cvzone.putTextRect(img, f'{model_type}: {int(X_real)}cm {int(Y_real)}cm {int(Z_real)}cm', (center_x, center_y - 10))
            cv2.circle(img, (screen_center_x, screen_center_y), 5, (0, 0, 255), 2)  # Screen center
            cv2.rectangle(img, (center_x - width // 2, center_y - height // 2),
                         (center_x + width // 2, center_y + height // 2), (255, 0, 0), 2)  # Bounding box

    # Display the frame
    cv2.imshow("Objectron Object Tracking with 3D Positions", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to quit
        break

camera.release()
cv2.destroyAllWindows()
