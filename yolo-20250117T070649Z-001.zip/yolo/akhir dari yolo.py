import cv2
import numpy as np
from ultralytics import YOLO
import RPi.GPIO as GPIO
import time

# Setup GPIO for L293D motor driver
GPIO.setmode(GPIO.BCM)

# Motor driver pins
ENA = 2    # Enable pin for left motor
IN1 = 3    # Left motor forward
IN2 = 4    # Left motor backward
ENB = 17   # Enable pin for right motor
IN3 = 18   # Right motor forward
IN4 = 25   # Right motor backward

GPIO.setup([ENA, ENB, IN1, IN2, IN3, IN4], GPIO.OUT)

# PWM setup
pwm_left = GPIO.PWM(ENA, 100)  # Left motor PWM
pwm_right = GPIO.PWM(ENB, 100)  # Right motor PWM
pwm_left.start(0)
pwm_right.start(0)

# Load YOLOv8 model
model = YOLO("yolov8n.pt")

# Target classes (adjust based on your use case)
TARGET_CLASSES = ["person", "bottle", "cup", "book"]  # Classes to avoid

# Camera setup
camera = cv2.VideoCapture(0)
camera.set(3, 640)  # Width
camera.set(4, 480)  # Height

# Screen center
screen_center_x = 320
screen_center_y = 240

# Function to control motors
def control_motors(steering, speed):
    if steering < -10:  # Turn right
        GPIO.output(IN1, False)
        GPIO.output(IN2, True)
        GPIO.output(IN3, True)
        GPIO.output(IN4, False)
    elif steering > 10:  # Turn left
        GPIO.output(IN1, True)
        GPIO.output(IN2, False)
        GPIO.output(IN3, False)
        GPIO.output(IN4, True)
    else:  # Move straight
        GPIO.output(IN1, True)
        GPIO.output(IN2, False)
        GPIO.output(IN3, True)
        GPIO.output(IN4, False)

    # Adjust speed
    pwm_left.ChangeDutyCycle(speed)
    pwm_right.ChangeDutyCycle(speed)

# Main loop
try:
    while True:
        success, frame = camera.read()
        if not success:
            break

        # Run YOLOv8 object detection
        results = model(frame, show=False)
        detected = False
        steering = 0
        speed = 50

        for result in results[0].boxes:
            box = result.xyxy[0].numpy()  # Bounding box: [x1, y1, x2, y2]
            conf = result.conf[0].item()  # Confidence score
            cls_id = int(result.cls[0].item())  # Class ID
            class_name = model.names[cls_id]  # Class name

            if class_name in TARGET_CLASSES and conf > 0.5:
                detected = True
                x1, y1, x2, y2 = map(int, box)
                center_x = (x1 + x2) // 2  # Center of the bounding box
                center_y = (y1 + y2) // 2

                # Determine steering direction
                if center_x < screen_center_x - 50:  # Object is on the left
                    steering = 45  # Turn left
                elif center_x > screen_center_x + 50:  # Object is on the right
                    steering = -45  # Turn right
                else:
                    steering = 0  # Move straight

                # Adjust speed based on object proximity (bounding box width)
                bbox_width = x2 - x1
                if bbox_width > 200:  # Very close object
                    speed = 10
                elif bbox_width > 100:  # Moderately close
                    speed = 30
                else:  # Far
                    speed = 50

                # Draw bounding box and information
                cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
                cv2.putText(frame, f"{class_name}: {conf:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # If no object is detected, move straight at full speed
        if not detected:
            steering = 0
            speed = 50

        # Control motors
        control_motors(steering, speed)

        # Display the frame
        cv2.imshow("Obstacle Avoider", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

except KeyboardInterrupt:
    print("Stopping...")
finally:
    # Cleanup
    pwm_left.stop()
    pwm_right.stop()
    GPIO.cleanup()
    camera.release()
    cv2.destroyAllWindows()
